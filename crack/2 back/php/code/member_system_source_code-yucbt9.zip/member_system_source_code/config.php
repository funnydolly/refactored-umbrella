<?php
	
	// set the database connection info
	define("DB_SERVER", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWD", "password");
	define("DB_NAME", "tutorials");

	// define the some extra stuff
	define("SITE_ADDR", "http://localhost/tutorials/user_login");

?>